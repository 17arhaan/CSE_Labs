from django.contrib import admin
from .models import Works, Lives

admin.site.register(Works)
admin.site.register(Lives)
